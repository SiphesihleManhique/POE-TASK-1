/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author st10100073
 */
public class Task {
    int total;
    public boolean checkTaskDescription(String description)
    {
        boolean descrip = false;
        if(description.length() <=50)
        {
            descrip = true;
        }
        
        return descrip;
    }
    public String createTaskID(String taskName, String developerDetails, int numbOfTasks)
    {
        
        String taskID = taskName.substring(0, 2) + ":" + numbOfTasks + ":" + developerDetails.substring(developerDetails.length()-3);
          
        return taskID.toUpperCase();
    }
    public String printTaskDetails(String taskName, String taskDescription, String firstName, String lastName, int durations, String taskID, String taskStatus)
    {
       return "Task Name\t"+taskName+"\nTask Description\t"+taskDescription+"\nDeveloper Details\t"+firstName+" "+lastName+"\nTaskID\t"+taskID+"\nDuration\t"+durations+"\nTask Status\t"+taskStatus; 
    }
    public int returnTotalHours(int hours)
    {
        total = total + hours;
        return total;
    }
    
}
