/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniel
 */
public class showReport {
    String[] developer;
    String[] taskStatuses;
    String[] taskNamee;
    String [] devName; 
    int[] taskDurations;
    
    
    public static String displayDone(String[] developer,String[] taskStatuses,String[] taskNamee,int[] taskDurations){
        for (int i = 0; i < taskStatuses.length;i++){
            if("Done".equalsIgnoreCase(taskStatuses[i])){
                return("Developer:" + developer[i])+
                        "\nTask name: " + taskNamee[i] +
                        "\nDuration :" + taskDurations[i];
            }
        }
        return null;
    }
    public static String showLongestDuration(String[] developer,int[] taskDurations){
        int longestDuration= taskDurations[0];
        String name = null;
        for (int i =0;i<taskDurations.length;i++){
           if (longestDuration<taskDurations[i]){
            longestDuration = taskDurations[i];
            name=developer[i];
        }
        }
        return longestDuration + name;
    }
    public static String searchTaskByName(String searchName,String[] developer,String[] taskStatuses[],String taskNamee[]){
        for (int i=0;i<taskNamee.length;i++){
            if(!taskNamee[i].equals(searchName)){
            } else {
                return(taskNamee[i] + "\n" + developer[i] + "\n" + taskStatuses[i]);
            }
                
            }
        return null;
        }
    public static String searchDeveloper(String searchDeveloper,String []devName,String[] taskStatuses,String[] taskNamee){
        for (int i =0; i <devName.length;i++){
            if (devName[i].equals(searchDeveloper)){
                        return(taskNamee[i] + "\n" + taskStatuses[i]);

            }
        }
        return null;
    }
    public static String displayReport(String[] devName, String[] taskStatuses,String[] taskNamee[],int[] taskDurations){
    for (int i=0; i<devName.length; i++){
    return (devName[i] + "\n" + taskStatuses[i] + "\n" + taskNamee[i] + "\n" + taskDurations[i]);
    }

    return null;
    }
        }
