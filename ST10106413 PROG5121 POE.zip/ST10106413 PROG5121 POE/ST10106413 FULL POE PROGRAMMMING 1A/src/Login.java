 */
package st10100073_Task1;
/**
 *
 * @author st10100073
 */
public class Login {
    
    public boolean checkUserName(String username)
    {
        boolean checkUnder = false;
        for (int i = 0; i < username.length(); i++) {
            if((int)username.charAt(i) == 95 && username.length() <=5)
            {
                checkUnder = true;
            }
           
        }
       if(checkUnder == true )
       {
         return true;
        }
       else
       {
         return false;
       }
       
    }// end of check user name method
    
    public boolean checkPasswordComplexity(String password)
    {
        boolean capital = false;
        boolean number = false;
        boolean scpecialChar = false;
        
        for (int i = 0; i < password.length(); i++) {
            if((int)password.charAt(i) >=65 && (int)password.charAt(i) <=90)
            {
                capital = true;
            }
            if((int)password.charAt(i)>= 48 && (int)password.charAt(i)<= 57)
            {
                number = true;
            }
            if((int)password.charAt(i) >= 32 && (int)password.charAt(i) <=47 || (int)password.charAt(i) >= 58 && (int)password.charAt(i) <=64 || (int)password.charAt(i) >=91 && (int)password.charAt(i)<=96 || (int)password.charAt(i) >= 123 && (int)password.charAt(i) <=127);
            {
                scpecialChar = true;
            }
        }// end of for loop 
        
        // check when all 4 conditions for password complexity is met
        if(capital == true && number == true && scpecialChar == true && password.length() <=8)
       {
            return true;
        }
        
        
        return false;
    }
    
    public String registerUser(String username, String password)
    {
        if(checkUserName(username) == true)
        {
            return "Username successfully captured";
        }
       else
        {
           return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length";
        }
     
    }
    
    public boolean loginUser(String logUsername, String LogPassword, String username, String password)
    {
        if(username.equals(logUsername) && password.equals(LogPassword))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String returnLoginStatus(String first,String username, String password, String loginUsername, String loginPassword){
         if (loginUser(username,password,loginUsername,loginPassword)==true){
             return "Welcome "+first+" you have been successfully logged in";
         }
         
         else{
             return "Welcome "+first+" you are not logged in, you have entered the incorrect password/username";
         }
     
     }
    
}
